#include <iostream>
using namespace std;

class Person
{
public:
    string name;
    int age;

    Person(string n, int a)
    {
        name = n;
        age = a;
    }
};
class Student : public Person
{
public:
    int rollNo;
    Student(string n, int a, int r) : Person(n, a)
    {
        rollNo = r;
    }
    void display()
    {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "RollNo: " << rollNo << endl;
    }
};
int main()
{
    Student s("Ali", 18, 101);
    s.display();

    return 0;
}