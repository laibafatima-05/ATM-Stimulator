#include <iostream>
using namespace std;

class Student
{
    int rollNo;

public:
    void setRollNo();
    int getRollNo();
};
void Student::setRollNo()
{
    rollNo = 10;
}
int Student ::getRollNo()
{
    return rollNo;
}
class CollegeStudent : public Student
{
    int marks;

public:
    void setData();
    void display();
};
void CollegeStudent::setData()
{
    marks = 90;
}
void CollegeStudent::display()
{
    cout << "Roll Number: " << getRollNo() << endl;
    cout << "Marks: " << marks << endl;
}
int main()
{
    CollegeStudent student;

    student.setRollNo();
    student.setData();
    student.display();

    return 0;
}