#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    cout << " Constants in C++ " << endl;
    const int a = 45;
    cout << " The value of a was " << a << endl;
    // a = 30; // You will get an erroe bcz a is constant
    cout << " The value of a is " << a << endl;

    cout << " Manipulators in C++ " << endl;
    int x = 5, b = 45, c = 12345;
    cout << "The value of x without setw is " << x << endl;
    cout << "The value of b without setw is " << b << endl;
    cout << "The value of c without setw is " << c << endl;

    cout << "The value of x is: " << setw(5) << x << endl;
    cout << "The value of b is: " << setw(5) << b << endl;
    cout << "The value of c is: " << setw(5) << c << endl;

    cout << " Operator Precedence " << endl;
    int a = 30, b = 10;
    int c = ((((a * 2) - b) + 45) - 20);
    cout << c;
    return 0;
}