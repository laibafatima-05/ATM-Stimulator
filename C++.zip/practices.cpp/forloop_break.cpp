#include <iostream>
using namespace std;

int main()
{
    for (int i = 1; i <= 100; i++)
    {
        if (i % 7 == 0 && i % 11 == 0)
        {
            cout << "First number = " << i;
            break;
        }
    }
    return 0;
}