#include <iostream>
using namespace std;

class Calculator
{
public:
    int add(int a, int b)
    {
        return a + b;
    }

    int add(int a, int b, int c)
    {
        return a + b + c;
    }
};
int main()
{
    Calculator obj;
    int a = 5, b = 10, c = 15;
    cout << obj.add(a, b) << endl;
    cout << obj.add(a, b, c) << endl;
    return 0;
}